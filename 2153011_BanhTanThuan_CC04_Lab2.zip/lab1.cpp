#include "lab1.h"

StudentManagementSystem::StudentManagementSystem(int max_students) {
    this->names = new std::string[max_students];
    this->scores = new int[max_students];
    this->num_students = 0;
    this->max_students = max_students;
}

StudentManagementSystem::~StudentManagementSystem() {
    delete[] this->names;
    delete[] this->scores;
}

void StudentManagementSystem::add_student() {
    // if the array is full, increase its capacity by doubling it
    if (num_students >= max_students) {
        max_students *= 2;
        std::string* new_names = new std::string[max_students];
        int *new_scores = new int[max_students];
        for (int i = 0; i < num_students; i++) {
            new_names[i] = names[i];
            new_scores[i] = scores[i];
        }
        delete[] names;
        delete[] scores;

        names = new_names;
        scores = new_scores;
    }

    std::string name;
    int score;
    std::cout << "Enter student name: ";
    std::cin >> name;
    std::cout << "Enter student score: ";
    std::cin >> score;

    this->names[num_students] = name;
    this->scores[num_students] = score;
    num_students++;

    std::cout << "Student added successfully." << std::endl;

}

void StudentManagementSystem::display_students() {
    if (num_students == 0) {
        std::cout << "No students found!" << std::endl;
        return;
    }

    std::cout << "List of students:" << std::endl;
    for (int i = 0; i < num_students; i++) {
        std::cout << i + 1 << ". " << names[i] << " (score: " << scores[i] << ")" << std::endl;
    }
}

void StudentManagementSystem::display_best_students() {
    if (num_students == 0) {
        std::cout << "No students found!" << std::endl;
        return;
    }

    int highest_score = -1;
    for (int i = 0; i < num_students; i++) {
        if(highest_score < scores[i]){
            highest_score = scores[i];
        }
    }

    std::cout << "List of Best students:" << std::endl;
    for (int i = 0; i < num_students; i++) {
        if(scores[i] == highest_score) std::cout << i + 1 << ". " << names[i] << " (score: " << scores[i] << ")" << std::endl;
    }
}

void StudentManagementSystem::remove_student() {
    if (num_students == 0) {
        std::cout << "No students found!" << std::endl;
        return;
    }

    std::string name;
    std::cout << "Enter student name: ";
    std::cin >> name;

    bool found = false;
    for (int i = 0; i < num_students; i++) {
        if (names[i] == name) {
            found = true;

            // Remove the student by shifting all the elements after it
            // one position to the left
            for (int j = i; j < num_students - 1; j++) {
                names[j] = names[j + 1];
                scores[j] = scores[j + 1];
            }

            num_students--;

            std::cout << "Student removed successfully." << std::endl;

            break;
        }
    }

    if (!found) {
        std::cout << "Student not found!" << std::endl;
    }
}

int main() {
    int max_students;
    std::cout << "Enter the maximum number of students: ";
    std::cin >> max_students;

    StudentManagementSystem sms(max_students);

    int choice;
    while (true) {
        std::cout << "Choose an option:" << std::endl;
        std::cout << "1. Add a student" << std::endl;
        std::cout << "2. Display all students" << std::endl;
        std::cout << "3. Display best students" << std::endl;
        std::cout << "4. Remove a student" << std::endl;
        std::cout << "5. Quit" << std::endl;
        std::cin >> choice;

        switch (choice) {
            case 1:
                sms.add_student();
                break;
            case 2:
                sms.display_students();
                break;
            case 3:
                sms.display_best_students();
                break;
            case 4:
                sms.remove_student();
                break;
            case 5:
                return 0;
            default:
                std::cout << "Invalid choice!" << std::endl;
                break;
        }
    }
}
