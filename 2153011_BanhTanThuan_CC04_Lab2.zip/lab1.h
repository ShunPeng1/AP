#ifndef LAB1_H
#define LAB1_H

#include <iostream>
#include <string>


class StudentManagementSystem {
private:
    std::string* names;
    int* scores;
    int num_students;
    int max_students;

public:
    StudentManagementSystem(int max_students);
    ~StudentManagementSystem();

    void add_student();
    void display_students();
    void remove_student();
    void display_best_students();
};

#endif // LAB1_H
