#include "lab1.h"

// Constructor for the Student class
Student::Student(std::string name = "", int score = 0) {
    this->name = name;
    this->score = score;
}

// Implementation of the SetName method
void Student::SetName(std::string name) {
    this->name = name;
}

// Implementation of the SetScore method
void Student::SetScore(int score) {
    this->score = score;
}

// Implementation of the GetName method
std::string Student::GetName() {
    return this->name;
}

// Implementation of the GetScore method
int Student::GetScore() {
    return this->score;
}

// Constructor for the StudentManagementSystem class
StudentManagementSystem::StudentManagementSystem(int max_students) {
    this->students_list = new Student*[max_students];
    this->num_students = 0;
    this->max_students = max_students;
}

// Destructor for the StudentManagementSystem class
StudentManagementSystem::~StudentManagementSystem() {
    for(int i = 0 ; i<this->num_students; i++){
        delete students_list[i];
    }
    delete[] this->students_list;
}


void StudentManagementSystem::add_student() {
    // if the array is full, increase its capacity by doubling it
    if (num_students >= max_students) {
        max_students *= 2;
    
        Student **new_students = new Student*[max_students]; 
        for (int i = 0; i < num_students; i++) {
            new_students[i] = students_list[i];
        }
        delete[] students_list;
        students_list = new_students;
        
    }

    std::string name;
    int score;
    std::cout << "Enter student name: ";
    std::cin >> name;
    std::cout << "Enter student score: ";
    std::cin >> score;

    Student *new_student = new Student(name, score);
    this->students_list[num_students] = new_student;
    num_students++;

    std::cout << "Student added successfully." << std::endl;

}

void StudentManagementSystem::display_students() {
    if (num_students == 0) {
        std::cout << "No students found!" << std::endl;
        return;
    }

    std::cout << "List of students:" << std::endl;
    for (int i = 0; i < num_students; i++) {
        std::cout << i + 1 << ". " << students_list[i]->GetName() << " (score: " << students_list[i]->GetScore() << ")" << std::endl;
    }
}

void StudentManagementSystem::display_best_students() {
    if (num_students == 0) {
        std::cout << "No students found!" << std::endl;
        return;
    }

    int highest_score = -1;
    for (int i = 0; i < num_students; i++) {
        if(highest_score < students_list[i]->GetScore()){
            highest_score = students_list[i]->GetScore();
        }
    }

    std::cout << "List of Best students:" << std::endl;
    for (int i = 0; i < num_students; i++) {
        if(students_list[i]->GetScore() == highest_score) std::cout << i + 1 << ". " << students_list[i]->GetName() << " (score: " << students_list[i]->GetScore() << ")" << std::endl;
    }
}

void StudentManagementSystem::remove_student() {
    if (num_students == 0) {
        std::cout << "No students found!" << std::endl;
        return;
    }

    std::string name;
    std::cout << "Enter student name: ";
    std::cin >> name;

    bool found = false;
    for (int i = 0; i < num_students; i++) {
        if (students_list[i]->GetName() == name) {
            found = true;

            // Remove the student by shifting all the elements after it
            // one position to the left
            for (int j = i; j < num_students - 1; j++) {
                students_list[j]->SetName(students_list[j+1]->GetName());
                students_list[j]->SetScore(students_list[j+1]->GetScore());
            }

            num_students--;

            std::cout << "Student removed successfully." << std::endl;

            break;
        }
    }

    if (!found) {
        std::cout << "Student not found!" << std::endl;
    }
}

int main() {
    int max_students;
    std::cout << "Enter the maximum number of students: ";
    std::cin >> max_students;

    StudentManagementSystem sms(max_students);

    int choice;
    while (true) {
        std::cout << "Choose an option:" << std::endl;
        std::cout << "1. Add a student" << std::endl;
        std::cout << "2. Display all students" << std::endl;
        std::cout << "3. Display best students" << std::endl;
        std::cout << "4. Remove a student" << std::endl;
        std::cout << "5. Quit" << std::endl;
        std::cin >> choice;

        switch (choice) {
            case 1:
                sms.add_student();
                break;
            case 2:
                sms.display_students();
                break;
            case 3:
                sms.display_best_students();
                break;
            case 4:
                sms.remove_student();
                break;
            case 5:
                return 0;
            default:
                std::cout << "Invalid choice!" << std::endl;
                break;
        }
    }
}
